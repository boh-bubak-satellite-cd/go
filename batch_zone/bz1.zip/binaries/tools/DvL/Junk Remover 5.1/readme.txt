
   ##### #######
   ##### #######
      ## ##   ###     ###       ###   ###      ###                ###
      ## ##    ##    ######  #############    ######  ##    ##   ######  #######
      ## ##   ###   ### ###  #### ####  ##   ### ###  ##    ##  ### ###  #######
      ## ##  ###   ###   ### ##    ##   ###  ##   ### ###  ###  ##   ### ####
      ## ######    ######### ##    ##   ### ###    ##  ##  ##  ######### ###
      ## ## ####   ######### ##    ##   ### ###    ##  ######  ######### ###
      ## ##  ###   ##        ##    ##   ### ###    ##  ######  ##        ###
      ## ##   ###  ###    #  ##    ##   ###  ##   ###   ####   ###    #  ###
  #  ### ##    ###  ### ###  ##    ##   ###  ### ###    ####    ###  ##  ###
  #####  ##     ### #######  ##    ##   ###   ######     ##     #######  ### �
   ####                ###                      ###                ###

        Welcome to Junk Remover �, the ultimate BATch system cleaner !!!
        ----------------------------------------------------------------

 Contact me at : dvl2003ro@yahoo.co.uk
                  =====================

oooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo



+------------+
� DISCLAIMER �
+------------+
 USE this utility at YOUR OWN RISK !!!
 I'm NOT responsable for any damage caused to yoursor any other computer ...
 Junk Remover has been extensively tested in Win9X/IE 4.01 and it works fine on 
my IBM PC/233 mhz, 64 MB memory, 200 MB hard drive (that's why i've created Junk 
Remover). 
 It also works with IE5 and IE6.
 I can't say how well it will work on your system.
 It's YOUR responsibility to make sure that Junk Remover does what you want, that
Junk Remover and other programs don't conflict, and that it works with your OS.
 Use the program only if u have a clean windows instalation, and use it with no 
applications opened. (FOR YOUR OWN GOOD).
 I assume that you use only Windoze (Win9X), and not a dual os system.

+-------------+
� SUGGESTIONS �
+-------------+
 Run Junk Remover at weekly. Defrag if you free up a lot of space.
 Do not rename and change your original name and location of your temp, cache, 
history, favorites a.s.o. folders.(Please leave them in the original place and 
locations, with the original names).
 Do not put any .txt files on c:\ coze Junk Remover will remove
ALL of them.
 In the safety of fully functionality of the program you should NOT delete any 
Junk Remover prog-files.

+---------+
� PURPOSE �
+---------+
 The main purpose of Junk Remover is a better and cleaner system. 
 It is NOT the purpose of Junk Remover to safeguard your privacy, although 
it helps. 
 The time consuming process of wiping free space prevents files from
being recovered.



oooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo



 Package contains :
  ================
--> JR51.bat      ( 4.415 bytes)
--> ReadMe.txt    ( 5.689 bytes)
--> JR51.ico      ( 3.262 bytes)

Safety Notes : It's purpose it'a a better and cleaner system.
============   Use the program only if u have a clean windows instalation,
               and use it with no applications opened. (FOR YOUR OWN GOOD).
               I assume you use only Windoze (Win9X), and not a dual os system.
               Do not put any .txt files on c:\ coze Junk Remover will remove
               ALL of them.
               Do not rename and change your original name and location of your
               temp, cache, history, favorites a.s.o. folders.(Please leave them
               in the original place and locations, with the original names).

What "junks" is Junk Remover "removing" ?
======================================= 

bad = registry files that the system marks as bad
bak = duplicate (backup) files
chk = ScanDisk disk error files
dmp = memory dump files
fts = temporary files recreated by Windows as needed
gid = help files search data
old = copy of older version
prv = log files created by past windows boot-ups
syd = temporary backup files
tmp = temporary files
*.$*= temporary files
*.~*= temporary files
~*.*= temporary files
*.??~=temporary files
mscreate.dir = creates folders during installations

These are files that are listed in EasyCleaner as unnecessary (which duplicate some of 
the files already listed):
These files are mainly backups, temporary and other unuseable files: *.tmp, ~*.*, *.~*,
*.?~?, *.aps, *.bak, *.bk?, *.bsc, *.dmp, *.ilk, *.pch, *.rws, *.sbr, backup*.wbk, *.$$$,
*.ncb, *.~mp, *.old, *.da0, *.chk. Easy Cleaner can also search for these files: *.fts, 
*.gid, *.mtx, *.nch, *.ftg, *.$db, *.db$. *. NCH are created when you read newsgroups with 
Microsoft Outlook. *.MTX files are created when a scanner-device is used. *.GID files are 
created when you execute *.HLP files. Usage of these files is currently quite unknown, but 
these files are still save to delete. You get mainly temporary free disk space when you 
delete these, because programs (or scanners) create these again when executed.

History & changes :
=================

In Junk Remover 5.1 � :
   ================

> change(s) i've done : - maked the cleaning process faster with the "FOR" command    
                        - removed some files and folders from deletion
                        - from now on, i will not use BATMNU.exe coze i have a webpage and
                          the program was downloaded and i don't want to have "problems",
                          that's why i've created a batch with a simple menu.

Junk Remover 5.1 � --> last update: 31.05.2003
================