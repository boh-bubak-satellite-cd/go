RESTART CONSTRUCTOR 7.0 by DvL & Ratty alias RC 7.0
===================================================

1.About !
  =======
This utility can easily create .bat files with restart
or similar commands, for ms-dos 6.0 or Win9x.

2.What's new ? 
  ============
- Kav detected RC 1 as Constructor.BAT.Restart.10
- Kav detected Force.bat as Trojan.BAT.Restart
- Kav detected RC 2 as Constructor.BAT.Restart.20
- Kav detected Restart1.bat as Trojan.BAT.ExitWindows.h
- Kav detected Restart2.bat as Trojan.BAT.Reboot.b
- Kav detected Restart4.bat as Trojan.BAT.ExitWindows.i
- Kav detected RC 3 as Constructor.BAT.Restart.30
- Kav detected Restart5.com as Trojan.Rebootpc.a
- Kav detected Restart6.com as Trojan.Rebootpc.b
- Kav detected RC 4 as Constructor.BAT.Restart.40
- Kav detected Restart1.bat as Trojan.BAT.ExitWindows.j
- Kav detected Restart2.bat as Trojan.BAT.ExitWindows.k
- Kav detected Restart3.bat as Trojan.BAT.ExitWindows.l
- Kav detected Restart4.bat as Trojan.BAT.ExitWindows.m
- Kav detected Restart5.bat as Trojan.BAT.ExitWindows.n
- Kav detected Restart6.bat as Trojan.BAT.ExitWindows.g
- Kav detected RC 5 as Constructor.BAT.Restart.50
- Kav detected Restart2.com as Trojan.Rebootpc.a
- Kav detected Restart4.com as Trojan.Rebootpc.b
- Kav detected Restart_4.com as Trojan.Rebootpc.a

Contacts:
=========
1.DvL    ---> dvl2003ro@yahoo.co.uk
2.Ratty  ---> ratty2001ro@yahoo.com and http://ratty.home.ro/