README for: BAT.InnerFire - By SAD1c

 Thanks and greets to the following peoples:
 DvL, all [rRlf] members (especially to Second Part To Hell), Hostfat, and
 everyone who read this.

 NAME: BAT.InnerFire
 TYPE: Batch
 ORIGINAL SIZE: 4792 Bytes
 STARTUP: With System.ini, Autoexec.bat and Winstart.bat, using undeletable
 folder technique.
 INFECTION: Infects *.bat & *.cmd in the current, parent, root and path
 folders (Appending)
 NET SPREAD: mIRC and a lot of P2Ps: Kazaa, Kazaa Lite, KMD, Morpheus,
 Edonkey, Emule, Overnet, Bear Share, LimeWire, Grokster