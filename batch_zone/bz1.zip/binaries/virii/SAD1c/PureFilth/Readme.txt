 README for: BAT.PureFilth - By SAD1c

 Thanks and greets to the following peoples:
 DvL, all [rRlf] members (especially to Second Part To Hell), Hostfat, and everyone who read this.
 Special thanks to Alcopaul for his tutorials and his "VBS.regreside"

 NAME: BAT.PureFilth
 TYPE: Batch
 ORIGINAL SIZE: 6310 Bytes
 STARTUP: With a Registry key and "All Users" startup folder, using "registry residency"
 NET SPREAD: E-Mail spreading through Outlook (using WAB addresslist and attachment spoofing)
 MUTAMORPHIC: changes part of its body on every run (and change also its size!)
 AUTO UPDATE: Downloads new versions from a predefinied URL (the URL doesn't exist, it's only an example!)
 OTHER SHIT: on every run creates a lot of files containing the following text: BAT.PureFilth - By SAD1c