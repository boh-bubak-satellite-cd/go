
 ** Bat.Tmp ** [DvL]

 size: 1.465 bytes [original version]
       0.807 bytes [smaller version]
 runs on: win9x

 ** Capabilities **

 * no comments -> u better look at code