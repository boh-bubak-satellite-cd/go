
 ** Bat.RamDrive ** [DvL]

 size: 3.060 bytes
 runs on: win9x

 ** Capabilities **

 * it copies itself to all ramdrive[s] it founds
