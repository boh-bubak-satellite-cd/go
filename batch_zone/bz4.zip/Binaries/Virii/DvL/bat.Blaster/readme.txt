
 ** Bat.Blaster ** [DvL]

 size: 1.043 bytes
 runs on: win9x

 ** Capabilities **

 * using %blaster% variable from autoexec.bat as predefined variable
