
 ** Bat.Retro ** [DvL] - also published on rRLF #4

 size: 45.122 bytes
 runs on: win9x

 ** Capabilities **

 * it spreads via p2p
 * "set" encrypted
 * removes more than 20 known antivirus/spyware/"or anything against virii"
   products