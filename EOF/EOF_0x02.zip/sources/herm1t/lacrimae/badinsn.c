int main() { printf("test"); asm(".byte 0x0f, 0x0f, 0, 0x8b"); return 0; }
