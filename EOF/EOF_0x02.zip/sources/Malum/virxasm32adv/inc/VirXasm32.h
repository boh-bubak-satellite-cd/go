
/*
 *  Include file of VirXasm32 for C/C++
 *  (X) Malum
 */

#ifndef _VIRXASM32_H_
#define _VIRXASM32_H_

/* must work :) */
extern
#ifdef __cplusplus
"C" 
#endif
unsigned long __cdecl VirXasm32 (const void *code);

#endif /* _VIRXASM32_H_ */
