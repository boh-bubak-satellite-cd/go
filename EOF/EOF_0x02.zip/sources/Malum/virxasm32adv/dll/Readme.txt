
- virxasm32_b.lib   for Borland C++, Delphi
- virxasm32_m.lib   for Microsoft C++
- virxasm32_old.lib for some old compilers
