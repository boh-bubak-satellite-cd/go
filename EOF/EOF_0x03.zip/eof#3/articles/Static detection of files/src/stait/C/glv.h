
//#pragma once



//#include <windows.h>
//#include <stdio.h>
//#include <conio.h> 
//#include "list


//extern list_dll ld;