/*
About backdoor:

This is simple backdoor with download/upload funcs + sending many 
other cmds (like tasklist,taskkill,service cmds... 
type help for cmds :)
I coded it because simple reason : I just want to code backdoor in C 
which file size is impressive.I put whole code in one function because 
my intentions was to code backdoor with process injecting possibilities
but I haven't do that(Don't ask me why).
If you want to download some file you must type every time full file location like
download C:\windows\notepad.exe).
When you want to upload some file type something like this
upload C:\windows\notepad.exe - type full file location.
for other commands type help.
This backdoor hasn't notification possibilities because of his size.
I tried to optimise code.
Im to tired tonight to explain everything because skyout is angry on me
and I don't know why....
Sad thing is that nobody from eof crew hasn't helped me to test this backdoor...

greets:
 (chaotic order :)

  skyout,        - boss or should I say dictator
                   I think that he is cloned Adolf Hitler
  izee,          - friend/bro

  wargame,       - some strange guy with elephant appetite

  radiation,     - what to say about someone which is talking a little
                   I must thank him for some good codes that he sended me

  berniee,       - Some guy which claims that everything that sorounds him is just his 
		   imagination...

  psycho rabbit, - who is he :| ?
  --------------
  others : tanMa - gdje si brate ? :)				      
*/