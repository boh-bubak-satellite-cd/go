#if !defined(AFX_STDAFX_H__0A7B0239_5F33_4974_AC07_8143DD9DAF2F__INCLUDED_)
#define AFX_STDAFX_H__0A7B0239_5F33_4974_AC07_8143DD9DAF2F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define _CRT_SECURE_NO_DEPRECATE 1

#define WIN32_LEAN_AND_MEAN	

#include <stdio.h>
#include <Windows.h>
#include <conio.h>


//{{AFX_INSERT_LOCATION}}

#endif // !defined(AFX_STDAFX_H__0A7B0239_5F33_4974_AC07_8143DD9DAF2F__INCLUDED_)
