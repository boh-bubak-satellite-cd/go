HEADING:
Get Windows and Office serial from Registry

DESCRIPTION:
With this small code you can get windows and office serials which are stored in the registry.
This code also decodes and formats them to a real serial.
The code will show you:
- Serial
- Product Name (if it exists)
- ProductId

To open it, use Visual Studio 2005 or open ProductIDSearcher.cpp