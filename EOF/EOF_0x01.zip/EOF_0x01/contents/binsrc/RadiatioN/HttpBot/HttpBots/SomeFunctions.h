
void RunApp(char *szCommand);
void DownloadFile(char *szUrl, char *szDestLocation);