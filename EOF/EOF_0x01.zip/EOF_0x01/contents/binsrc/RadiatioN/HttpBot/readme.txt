Example code to tutorial "Http Bots - the new state of the art"

No Copyright - free for any use

Written by RadiatioN in August-November 2006

Zine and group site:
EOF - Electrical Ordered Freedom
http://www.eof-project.net

My site:
RadiatioN's VX World
http://radiation.eof-project.net

Contact:
radiation[at]eof-project[dot]net

some nice greetings to Sky my good friend :)