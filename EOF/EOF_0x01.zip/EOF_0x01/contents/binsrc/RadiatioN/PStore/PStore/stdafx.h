
#pragma once

#define _CRT_SECURE_NO_DEPRECATE 1

#import "C:\WINDOWS\system32\pstorec.dll" 

using namespace PSTORECLib; 

#define WIN32_LEAN_AND_MEAN
#include <stdio.h>
#include <tchar.h>
#include <windows.h>
#include <conio.h>
