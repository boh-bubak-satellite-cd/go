HEADING:
Get IE cached data like searchstrings, auto fillup values for forms and passwords

DESCRIPTION:
With this short code you can read all stored data like search strings and IE cached 
passwords in the 'secure' data container in the system.
this code (should) work on all OS version of windows higher than 9x; i tried it on W2K SP4 and XP SP2

To open it, use Visual Studio 2005 or in subfolder "PStore" the PStore.cpp and stdafx.h for the header.