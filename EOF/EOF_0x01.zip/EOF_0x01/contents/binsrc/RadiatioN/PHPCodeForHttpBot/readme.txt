This are the php codes for the http bot management console.

To install it on a server follow this steps:
- Copy files to any directory
- Run "CreateTables.sql" in phpMyAdmin or mysql command line
- Edit config.php to your own settings

open "control.php" on a browser of your choice, enter password and have fun :)

No Copyright - free for any use

Written by RadiatioN in August-November 2006

Zine and group site:
EOF - Electrical Ordered Freedom
http://www.eof-project.net

My site:
RadiatioN's VX World
http://radiation.eof-project.net

Contact:
radiation[at]eof-project[dot]net

some nice greetings to Sky my good friend :)