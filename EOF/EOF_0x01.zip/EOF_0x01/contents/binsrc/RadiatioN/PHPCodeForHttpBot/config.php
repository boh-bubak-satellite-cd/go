<?php
//change this to the url of the MySQL server or leave localhost
$server='localhost';

//user for database
$user='root';

//password for database
$pw='root';

//name of database
$dbname='bot';

//password to management console
$botpw='bla';

//timeout in seconds when bot gets declared as offline
$timeout=10;
?>