This small app creates the auth key for regabot.
just insert the text to encrypt into the specific field, press encrpyt.
copy/past encrypted data to your IRC client and write it to the bots.

Example:
--------
Your DNS or IP: RadiatioN@radiation.users.undernet.org
(you get DNS or Ip when you write .dns in query to one of the bots)

Enter this to encrypt: RadiatioNradiation.users.undernet.org

enter result as here in IRC client: .auth Xknsk~suTxknsk~sut8q?4yoxy4tnoxto~4uxm

and now are you authed with all bots in the channel :)

No Copyright - free for any use

Written by RadiatioN in March-July 2006

Zine and group site:
EOF - Electrical Ordered Freedom
http://www.eof-project.net

My site:
RadiatioN's VX World
http://radiation.eof-project.net

Contact:
radiation[at]eof-project[dot]net

some nice greetings to Sky my good friend :)