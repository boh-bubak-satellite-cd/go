//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by BlindSpot.rc
//
#define IDD_DIALOG                      100
#define IDD_DIALOG_ADD                  101
#define IDD_DIALOG_BIND                 102
#define IDI_ICON                        103
#define IDM_ADD                         104
#define IDM_REMOVE                      105
#define IDM_BIND                        106
#define IDR_RT_EXE                      113
#define IDC_LIST                        1000
#define IDC_LIST_BOX                    1001
#define IDC_RADIO_TMPDIR                1002
#define IDC_PROGRESS_BAR                1003
#define IDC_CHECK_RUN                   1004
#define IDC_RADIO_SYSDIR                1005
#define IDC_RADIO_WINDIR                1006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        117
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           108
#endif
#endif
