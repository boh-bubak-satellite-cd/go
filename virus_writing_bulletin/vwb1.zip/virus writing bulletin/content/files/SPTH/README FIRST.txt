If you opened any of the RAR files before this text then you are not capable of fallowing instructions correctly.  ;)
Password for file is "password".
hh86