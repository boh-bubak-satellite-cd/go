#include <stdio.h>
#include <stdint.h>

extern main();
asm(".globl main; main: call _main; ret");

int foo(void)
{
	return 99;
}

void _main(void)
{
	uint32_t addr = (uint32_t)__builtin_return_address(0) - 5;
	int (*foo_ptr)(void) = (int(*)(void))(addr + (foo - main));
	printf("%d\n", foo_ptr());
}
