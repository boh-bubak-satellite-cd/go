static void inline bzero(void *dst, int size)
{
	int i;
	for (i = 0; i < size; i++)
		*((char*)dst + i) = 0;
}

static void inline memmove(void *dst_void, void *src_void, int len)
{
	char *dst = dst_void;
	char *src = src_void;
	if (src < dst && dst < src + len) {
		src += len;
		dst += len;
		while (len--)
			*--dst = *--src;
	} else {
		while (len--)
			*dst++ = *src++;
	}
}

static void inline memcpy(char *dst, char *src, int len)
{
	int i;
	for (i = 0; i < len; i++)
		*dst++ = *src++;
}
