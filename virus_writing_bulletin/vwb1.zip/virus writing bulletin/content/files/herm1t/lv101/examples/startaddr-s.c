#include <stdio.h>

asm(	".globl main; main:\n"
	"call 1f\n"
	"1: sub $(1b-main), (%esp)\n"
	"call _main\n"
	"popl %eax\n"
	"ret");

void _main(int addr)
{
	printf("The address of main() is %08x\n", addr);
}
