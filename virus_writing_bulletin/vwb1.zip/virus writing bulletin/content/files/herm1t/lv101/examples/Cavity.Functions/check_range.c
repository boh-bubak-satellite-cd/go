static cell_t *check_range(uint8_t *start, uint8_t *end)
{
	cell_t *list = NULL;
	uint8_t *ptr = start;
	int op_len, i, s;
	struct {
		uint32_t len, crc;
	} p[10];
	p[0].len = 15; p[0].crc = 0x11d50a7f;
	p[1].len = 14; p[1].crc = 0xe4ad564a;
	p[2].len = 15; p[2].crc = 0xd5cae9dc;
	p[3].len = 13; p[3].crc = 0xd6b6dcfd;
	p[4].len = 12; p[4].crc = 0x19fbc1f4;
	p[5].len = 11; p[5].crc = 0x34a6685b;
	p[6].len = 10; p[6].crc = 0x74d8dd25;
	p[7].len = 9;  p[7].crc = 0x6ed89f27;
	p[8].len = 8;  p[8].crc = 0xb7109f48;
	p[9].len = 7;  p[9].crc = 0x5d30a0da;	
	while (ptr < end) {
_next:		for (i = 0; i < 10; i++)
			if (crc32(0, ptr, p[i].len) == p[i].crc) {
				cell_t *q, *tmp;
				if ((tmp = malloc(sizeof(cell_t))) == NULL) {
_error:					free_list(list);
					return NULL;
				}
				s = i == 2 ? 2 : 1;
				tmp->ptr = ptr + s;
				tmp->len = p[i].len - s;
				tmp->next = NULL;
				if (list == NULL || tmp->len > list->len) {
					tmp->next = list;
					list = tmp;
				} else {
					q = list;
					while (q->next != NULL && q->next->len > tmp->len)
						q = q->next;
					tmp->next = q->next;
					q->next = tmp;
				}
				ptr += p[i].len;
				goto _next;
			}
		if ((op_len = mlde32(ptr)) <= 0)	/* "Illegal instruction! */
			goto _error;
		ptr += op_len;
	}
	return list;
}
