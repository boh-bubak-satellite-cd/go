int main(int argc, char **argv, char **envp)
{
	int i;
	char *selfexe;
	for (i = 0; envp[i + 1]; i++) ;
	for (selfexe = envp[i]; *selfexe++; ) ;
	puts(selfexe);
}
