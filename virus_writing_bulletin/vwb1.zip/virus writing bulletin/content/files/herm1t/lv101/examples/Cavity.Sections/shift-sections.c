	uint32_t u, t, x, j;
	for (i = 0; i < ehdr->e_phnum; i++)
		if (phdr[i].p_type == PT_LOAD && phdr[i].p_offset == 0)
			break;
	if (i == ehdr->e_phnum)
		goto badluck;

	MAKE_HOLE(0, 4096);
	memmove(m, m + 4096, sizeof(Elf32_Ehdr));
	ehdr = (Elf32_Ehdr*)m;
	memmove(m + sizeof(Elf32_Ehdr),
		m + 4096 + ehdr->e_phoff,
		ehdr->e_phnum * sizeof(Elf32_Phdr));
	ehdr->e_phoff = sizeof(Elf32_Ehdr);
	phdr = (Elf32_Phdr*)(m + ehdr->e_phoff);
	ehdr->e_shoff += 4096;
	shdr = (Elf32_Shdr*)(m + ehdr->e_shoff);
	phdr[i].p_vaddr -= 4096;
	phdr[i].p_filesz += 4096;
	phdr[i].p_memsz += 4096;
	u = phdr[i].p_vaddr;	

	Elf32_Dyn *dyn = NULL;
	for (x = 0, i = 0; i < ehdr->e_phnum; i++) {
		if (phdr[i].p_type == PT_PHDR) {
			phdr[i].p_offset = sizeof(Elf32_Ehdr);
			phdr[i].p_vaddr = phdr[i].p_paddr = u + sizeof(Elf32_Ehdr);
		} else
		if (phdr[i].p_offset > 0)
			phdr[i].p_offset += 4096;

		if (phdr[i].p_type == PT_INTERP)
			x = phdr[i].p_vaddr;
		if (phdr[i].p_type == PT_DYNAMIC)
			dyn = (Elf32_Dyn*)(m + phdr[i].p_offset);
	}

	for (t = 0, i = 1; i < ehdr->e_shnum; i++) {
		if (	t == 0 && x != 0 &&
			shdr[i].sh_addr != x &&
			shdr[i].sh_type != SHT_HASH &&
			shdr[i].sh_type != SHT_DYNSYM &&
			shdr[i].sh_type != SHT_REL &&
			shdr[i].sh_type != SHT_RELA &&
			shdr[i].sh_type != SHT_STRTAB &&
			shdr[i].sh_type != SHT_NOTE &&
			shdr[i].sh_type != SHT_GNU_verdef &&
			shdr[i].sh_type != SHT_GNU_verneed &&
			shdr[i].sh_type != SHT_GNU_versym &&
			shdr[i].sh_type != SHT_GNU_LIBLIST )
				t = i;
		if (shdr[i].sh_offset)
			shdr[i].sh_offset += 4096;
	}
	x = (char*)&phdr[ehdr->e_phnum] - m;
	for (i = x; i < shdr[1].sh_offset; i++)
		m[i] = 0xaa;
	if (dyn == NULL)
		goto badluck;		
	/* move sections */
//	putc(':');putx2(t);putc(10);
	for (i = 1; i < t; i++) {
//		putc('.');
		memmove(m + x, m + shdr[i].sh_offset, shdr[i].sh_size);
//		bzero(m + shdr[i].sh_offset, shdr[i].sh_size);
		for (j = 0; j < ehdr->e_phnum; j++)
			if (phdr[j].p_offset == shdr[i].sh_offset) {
				phdr[j].p_offset = x;
				phdr[j].p_vaddr = phdr[j].p_paddr = u + x;
				break;
			}
		for (j = 0; dyn[j].d_tag != DT_NULL; j++)
			if (dyn[j].d_un.d_val == shdr[i].sh_addr) {
				dyn[j].d_un.d_val = u + x;
			}
		shdr[i].sh_offset = x;
		shdr[i].sh_addr = u + x;
		x += shdr[i].sh_size + 128;
	}
badluck:
