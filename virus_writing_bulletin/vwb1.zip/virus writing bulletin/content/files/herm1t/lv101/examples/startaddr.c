#include <stdio.h>
#include <stdint.h>

asm(".globl main; main: call _main; ret");

int _main(void)
{
	uint32_t addr = (uint32_t)__builtin_return_address(0) - 5;
	printf("The address of main() is %08x\n", addr);
}
