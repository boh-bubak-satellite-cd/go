static cell_t *check_range(Elf32_Ehdr *ehdr, Elf32_Shdr *shdr)
{
	int i;
	cell_t *list = NULL;
	for (i = 1; i < ehdr->e_shnum; i++) {
		if (shdr[i].sh_flags & SHF_ALLOC) {
			int f = shdr[i + 1].sh_offset - shdr[i].sh_offset - shdr[i].sh_size;
			if (f < 6)
				continue;
			cell_t *q, *tmp;
			if ((tmp = malloc(sizeof(cell_t))) == NULL) {
				free_list(list);
				return NULL;
			}
			tmp->ptr = (char*)ehdr + shdr[i].sh_offset + shdr[i].sh_size;
			tmp->len = f;
			tmp->adr = shdr[i].sh_addr + shdr[i].sh_size;
			tmp->next = NULL;
#ifdef	MAKE_SPACE
			if (list == NULL) {
				list = tmp;
				q = list;
			} else {
				q->next = tmp;
				q = q->next;
			}
#else
			if (list == NULL || tmp->len > list->len) {
				tmp->next = list;
				list = tmp;
			} else {
				q = list;
				while (q->next != NULL && q->next->len > tmp->len)
					q = q->next;
				tmp->next = q->next;
				q->next = tmp;
			}
#endif
		}
	}
	return list;
}
