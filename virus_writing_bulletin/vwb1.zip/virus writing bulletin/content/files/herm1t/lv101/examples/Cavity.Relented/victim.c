#include <stdio.h>
#include <stdint.h>
#include <elf.h>

int main(int argc, char **argv)
{
	uint32_t base;
	for (base = (uint32_t)main & 0xfffff000; ; base -= 4096)
		if (*(uint32_t*)base == 0x464c457f)
			break;
	Elf32_Phdr *phdr = (Elf32_Phdr*)(base + ((Elf32_Ehdr*)base)->e_phoff);
	int i, j;
	for (i = 0; i < ((Elf32_Ehdr*)base)->e_phnum; i++) {
		if (phdr[i].p_filesz != phdr[i].p_memsz) {
			for (j = 0; j < 32; j++)
				printf("%02x ", *(uint8_t*)(phdr[i].p_vaddr + phdr[i].p_filesz + j));
			putchar('\n');
		}
	}
	return 0;
}
