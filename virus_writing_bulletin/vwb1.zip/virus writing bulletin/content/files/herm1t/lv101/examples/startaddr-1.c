#include <stdio.h>
#include <stdint.h>

asm(".globl main; main: call _main; ret");

int _main(int argc)
{
	uint32_t addr = *(uint32_t*)(&argc - 1) - 5;
	printf("The address of main() is %08x\n", addr);
}
