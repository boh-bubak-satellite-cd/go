import sys,os


if (len(sys.argv)!=2):
	print "Invalid argument"
	sys.exit(0)

d=open(sys.argv[1],"rb").read()
d=bytearray(d)
l=len(d)


name=os.path.splitext(os.path.basename(sys.argv[1]))[0]
s="char "+name+"[]=\n"
s=s+"\""
for i in range(0,l):
	if (i%16==0) and (i!=0):
		s=s+"\"\n\""	
	s=s+"\\x%0.2X" % (d[i])
s=s+"\";"
print s