#pragma once
#include "common.h"

uint32 crc32(uint32 crc, uint8 *buf, size_t size);
