Please read Lesson 1 (Codbrk02) for instructions on how to use these files!

Contents of Create:

TASM.exe        - Compiler (Assembler)
TLINK.exe       - Linker
TOAD.asm        - Source code for Toad virus


Contents of Pond:

FLY.com         - Basic com file (to infect)


Contents of Toad:

FLY(1-3).com    - Basic com files (to infect)
TOAD.com        - Actual working virus
