Please read Lesson 2 (Codbrk02) for instructions on how to
use these files!

Contents of Create:

TASM.exe       - Compiler (Assembler)
TLINK.exe      - Linker
TOAD2.asm      - Source code for Toad2 virus


Contents of Pond:

FLY(1-3).com         - Basic com files (to infect)


Contents of Toad:

FLY(1-3).com         - Basic com files (to infect)
TOAD2.com            - Actual working virus
