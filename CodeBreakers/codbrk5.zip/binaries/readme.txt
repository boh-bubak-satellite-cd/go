*CBVx-Zine #5 Binaries Editors Note*

Due to certain circumstances beyond my control I was unable to aquire byte 
for byte binary samples of *all* the viruses to which source is provided 
in this issue. It shouldn't be too much of a problem to compile the 
missing samples yourself, and I have included some of the most important/most
wanted ones already, I felt it necessary to note despite the fact. 

-Opic [CodeBreakers 1999]