import VirusClassLoader;

public class Main {

//---------- Main initialisation -------------------------
public static void main(String[] args) throws ClassNotFoundException {

    VirusClassLoader loader = new VirusClassLoader();

}

} // End class
