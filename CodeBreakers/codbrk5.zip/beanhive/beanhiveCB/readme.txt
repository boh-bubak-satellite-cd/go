Greetings!

After the quite verbose release of Strange Brew in the previous issue
of the Codebreakers zine you may be somewhat disappointed by the
relatively brief article written here.

Here are the sources of the applets that were used to distribute the 
beanhive virus.