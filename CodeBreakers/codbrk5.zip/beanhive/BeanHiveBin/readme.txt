Greetings!

This zip file contains the following files:
C8F67B~1 CLA         1,562  09-08-98  5:48p c8f67b45.class
BE93A2~1 CLA         4,025  09-08-98  5:48p be93a29f.class
BEANHI~1 CLA         1,139  09-08-98  5:48p BeanHive.class
A98B34~1 CLA           597  09-08-98  5:48p a98b34f2.class
DC98E7~1 CLA         2,780  09-08-98  5:48p dc98e742.class
E89A76~1 CLA         2,136  09-08-98  5:48p e89a763c.class
         6 file(s)         12,239 bytes
Please install them to the root directory of the codebreakers
web server so that they can be accessed by the url:
http://www.codebreakers.org/

Cheers,

LC