
  Batch Worm Generator
  by SeCoNd PaRt To HeLl  (spth@jet2web.cc)
  [www.spth.de.vu]


I.) What is the Batch Worm Generator?
II.) Freatures
III.) A small cut of my to-do list
IV.) Thanks and greets



I.)  What is the Batch Worm Generator?

The Batch Worm Generator or Constructor.BAT.BWG is propable the best Batch Virii Generator.
It generates Worms, which are able to spread in the Internet.
Every generated BWG-Worm is different, because of some nice techniques...
I try to make it impossible to detect all BWG-Worms, but KAV also tried to find the worms as I-Worm.BWG.a-f or BAT.BWG.a-c!
But now they don't detect any Worm!

BWG don't contain any binary code, because of that it no problem to read the outputs...



II.) Freatures

Infects:
   + BAT files (overwriting)
      - Windows Direction
      - Current Direction
      - Root Direction
      - Parents Direction
      - %path% Direction

dropping:
   + REG files
   + VBS files
   + JS files
   + PIF files
   + LNK files

copying:
   + desktop path
   + Disk A:

worming:
   + Self mailing via MS Outlook
   + KAZAA spreading
   + mIRC spreading
   + pIRCh spreading
   + vIRC spreading

autostart:
   + win.ini
   + Autostart Direction
      - german
      - english
   + Registry Key
   + system.ini

extra:
   + subst drive
   + message
   + include EICAR-Test-File
   + delete some AV progs
   + includeing 1000 Fake-Bytes
   + copying to a undelateable folder in windows



III.) A small cut of my to-do list

Here I write things, which I will add in one of the next versions:

PHP-dropping { I don't think, that I will manage it +fg+ )
HTM-dropping { I've tried it 100 times without success, but I will try it again and again and again... }
Other languages Autostart Direction { hmm, it could be possible }
Morpheus-spreading { VorteX!!! ;-) }
Other encryption techniques { perhaps from DUKE/SMF's Advanced Batch Mutator }




IV.) Thanks and greets

VorteX			: for the very good suggestions and bug reports, his batch viruses and for the interesting in my BWG ;-)
Worf			: for BAT/REG/PHP viruses and the "Where is the source"-mail every version +fg+
SnakeByte		: for progging help and totorials
Positron		: for his batch viruses
BlackCat		: for uploading my BWG @ your Page [http://hvx.cjb.net - down] - so BWG became famous
Dr. T			: for uploading my BWG @ your Page [http://www.ebcvg.com] - you also helped BWG to became famous
assassin007		: for pushing my BWG to the eBCVG #2

others I want to greets...

philet0ast3r, alcopaul, mgl, zed, all rRlf members, PetiK, [K]alamar, Duke/SMF, Hirosh, and all ppl ever wrote me an eMail ;-)




         Second Part To Hell
             spth@jet2web.cc
            [www.spth.de.vu]
