The Virus Hunter 
Taken From Pc Extreme Issue 21

Retro

http://retro.hosk.sk