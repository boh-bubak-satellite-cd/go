Warning Virus! 
Taken From .Net Christmas 2003

Retro

http://retro.hosk.sk