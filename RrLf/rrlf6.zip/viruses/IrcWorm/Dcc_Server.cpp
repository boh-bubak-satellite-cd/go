#include "stdafx.h"
#include "winsock2.h"
DWORD WINAPI DCC_TransferFile(LPVOID xSocket)
{
	//thread to transfer a file to incoming connection




	return 1;
}




