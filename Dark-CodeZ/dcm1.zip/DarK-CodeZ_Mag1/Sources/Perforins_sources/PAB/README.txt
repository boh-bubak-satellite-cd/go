 ______                                __     __ 
|   __ \.---.-.----.---.-.-----.-----.|__|.--|  |
|    __/|  _  |   _|  _  |     |  _  ||  ||  _  |
|___|   |___._|__| |___._|__|__|_____||__||_____|
                                                 
 _______           __              __     __ 
|   _   |.-----.--|  |.----.-----.|__|.--|  |
|       ||     |  _  ||   _|  _  ||  ||  _  |
|___|___||__|__|_____||__| |_____||__||_____|
______         __   
|   __ \.-----.|  |_ 
|   __ <|  _  ||   _|
|______/|_____||____|


by Perforin

__CHANGELOG__

V.1.2
--> Commands File getting crypted
V.1.3
--> Can make Batch Files now!
--> Bug fixxes
V.1.4
--> Can download textfiles!
V.1.5
--> Can execute Commands in the shell now
V1.6
--> Auto Update
--> Command listening fixxed to 30 seconds
V1.7
--> MD5 Hash Cracking
--> FTP Cracking
V1.8
--> Bug fixxes ( goto AGAIN; was fucked up)
--> Commands are now case insensitiv!
V1.9
--> new method for counting Bots
V2.0
--> Getting the newest milw0rm Exploits
--> Recoded the control center, working more with php files and iframes
--> General Bug fixxes
--> Downloading Wordlist for MD5 Hash Cracking and FTP Cracking
--> Panic command will disconnect Bot
--> Spy command added

___INSTALL___
 
1) Upload all the files on a webserver!
2) Have fun.

___CONFIG___

1) In line 62 you have to change the URL!
2) In line 72 you have to change the URL!
3) In line 136 you have to change the URL!
4) In line 175 you have to change the URL!
5) In line 218 you have to change the URL!
6) In line 386 you have to change the URL!

__CONTROL__

1) MAKE - Create a Batchfile.
2) DOWNLOAD - Downlaods a Text File.
3) EXECUTE - Executes a shell Command.
4) UPDATE - Updates the Bot.
5) START - Flood a website.
6) FTP CRACK - Crack a FTP Server.
7) MD5 CRACK - Crack a MD5 Hash.
8) MILW0rm - Shows you the newest Exploits.
9) SPY - Spy your Victim

___VISIT___

www.perforins-software.de.vu
www.dark-codez.org


