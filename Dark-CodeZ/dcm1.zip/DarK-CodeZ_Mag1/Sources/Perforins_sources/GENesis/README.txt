GENesis Bot README

___CONFIG___

In line 24 you have to change the URL!
In line 25 you have to change the Channel!
In line 26 you have to change the Port!
In line 299 you have to change the Update URL!
In line 301 you have to change the Update URL!

___CONTROL___

-spam-      [Spamt im Channel]
-kill-      [Killt den Bot]
-credits-   [Zeigt euch die Credits]
-from-      [Zeigt die IP]
-version-   [Zeigt die Bot Version]
-mille-     [Zeigt die neusten Exploits]
-crack-     [Crackt einen MD5 Hash]
-md5gen-    [Erstellt euch einen MD5 Hash]
-ipgen-     [Generiert eine IP]
-ping-      [Pingt einen Server]
-pub-       [Versucht anonymous login]
-dns-       [L�st die DNS in eine IP auf]
-sql-       [Scannt eine IP nach MS SQL ab]
-update-    [Ziel URL mit Update]
-help-      [Zeigt die Hilfe an]

___VISIT___

www.perforins-software.de.vu
www.dark-codez.org