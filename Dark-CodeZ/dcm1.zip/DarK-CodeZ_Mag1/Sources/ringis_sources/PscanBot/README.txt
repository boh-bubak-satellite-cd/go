-------- [`\ Commands for PubScanBot /�] --------

            #-- (c) by ringwrath-4 --#
             #          @           #
              #  CoderZ-Heaven.de  #
               #  DarK-CodeZ.org  #


Scanning_________:

[ Public FTPs ]
scan.pub.start -  Start Pub Scanner
scan.pub.stop  -  Stop Pub Scanner
scan.pub.stat  -  Get PubScanner Status
scan.pub.count -  Get count of found Pubs
scan.pub.pubs  -  Get found pubs

___________________;

Main Administration:

[ Main ]
main.delete     -   Kills all Active bots in Channel
