Contempt-Bot - Stub.dll by Neo2k8 

Funktionen : 
Msgbox [ Zeigt Messagebox auf Remote PC ] 
Start [ Startet Files oder Internetseiten ] 
Say [ Spricht einem nach ] 
spam| [Spams the Channel] 
update| [Webdownloader + Execut this File] 
where | [Where the Bot is] 
Ftp Scanner [ Verbugt, scannt nach Port 21 ] [Bug : Scannt nicht direkt nach anonymous ] 
MD5 Hash Cracker [ Cracked einen MD5 Hash] 
screenget [Macht einen Screenshot und upped ihn auf angegebenen FTP] 
screenget auto [Macht automatisch soviele Screenshots wie angegeben und upped sie auf angegebenen FTP] 
recon [Reconnectet den Bot] 
restart [Startet kompletten Bot neu] 


Module sind nicht hier gepostet!!!!! 
Der Bot war nur zur �bung gedacht ;) Ich bin gerade dabei einen besseren zucoden :D