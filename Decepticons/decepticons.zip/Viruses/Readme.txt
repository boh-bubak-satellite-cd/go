all these sources is edited by EasyCode Masm

if you don't read the comments very well or you have some problems in compiling the virus please install EasyCode Masm and open the project from *.ecp

BE ware while running any .exe file because you will be infected

Tibo